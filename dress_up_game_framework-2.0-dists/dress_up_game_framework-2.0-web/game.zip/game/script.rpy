﻿label start:
    jump creator